#ifndef _KBHIT_
#define _KBHIT_

#include <ncurses.h>
#include <sys/ioctl.h>
#include <termios.h>
#include <stdlib.h>

using namespace std;

static int curKey;
int kbhit();

#endif